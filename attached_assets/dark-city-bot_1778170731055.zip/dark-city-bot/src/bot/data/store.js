export const ADMIN_ROLE_ID = "1297881409012240445";
export const PRISON_ROLE_ID = "1456560553282764830";
export const CITIZEN_ROLE_ID = "1305984216835555359";

export const prisonStore = new Map();
export const violationsStore = new Map();
export const violationCounters = new Map();
export const autoRepliesStore = new Map();
export const afkStore = new Map();
