import { REST, Routes } from "discord.js";
import * as ping from "./commands/ping.js";
import * as kick from "./commands/kick.js";
import * as ban from "./commands/ban.js";
import * as unban from "./commands/unban.js";
import * as mute from "./commands/mute.js";
import * as unmute from "./commands/unmute.js";
import * as warn from "./commands/warn.js";
import * as warnings from "./commands/warnings.js";
import * as clearwarn from "./commands/clearwarn.js";
import * as clear from "./commands/clear.js";
import * as slowmode from "./commands/slowmode.js";
import * as lock from "./commands/lock.js";
import * as unlock from "./commands/unlock.js";
import * as role from "./commands/role.js";
import * as nickname from "./commands/nickname.js";
import * as serverinfo from "./commands/serverinfo.js";
import * as userinfo from "./commands/userinfo.js";
import * as announce from "./commands/announce.js";
import * as help from "./commands/help.js";
import * as jail from "./commands/jail.js";
import * as restoreRoles from "./commands/restore_roles.js";
import * as giveRole from "./commands/give_role.js";
import * as removeRoleCmd from "./commands/remove_role_cmd.js";
import * as violation from "./commands/violation.js";
import * as violationsList from "./commands/violations_list.js";
import * as myViolations from "./commands/my_violations.js";
import * as pay from "./commands/pay.js";
import * as autoReply from "./commands/auto_reply.js";
import * as line from "./commands/line.js";
import * as afk from "./commands/afk.js";

const token = process.env["DISCORD_BOT_TOKEN"];
const clientId = process.env["DISCORD_CLIENT_ID"];

if (!token || !clientId) {
  console.error("Missing DISCORD_BOT_TOKEN or DISCORD_CLIENT_ID");
  process.exit(1);
}

const commands = [
  ping, kick, ban, unban, mute, unmute,
  warn, warnings, clearwarn, clear, slowmode,
  lock, unlock, role, nickname, serverinfo,
  userinfo, announce, help,
  jail, restoreRoles, giveRole, removeRoleCmd,
  violation, violationsList, myViolations, pay,
  autoReply, line, afk,
].map((c) => c.data.toJSON());

const rest = new REST().setToken(token);

(async () => {
  try {
    console.log(`Registering ${commands.length} application commands...`);
    const data = await rest.put(Routes.applicationCommands(clientId), { body: commands });
    console.log(`Successfully registered ${data.length} commands globally.`);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();
