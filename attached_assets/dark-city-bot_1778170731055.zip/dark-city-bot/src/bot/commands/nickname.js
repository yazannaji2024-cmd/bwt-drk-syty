import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("تغيير_اسم")
  .setDescription("تغيير أو إزالة لقب عضو")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames)
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المستهدف").setRequired(true)
  )
  .addStringOption((option) =>
    option.setName("اللقب").setDescription("اللقب الجديد (اتركه فارغاً للإزالة)").setMaxLength(32).setRequired(false)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageNicknames)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية تغيير الألقاب.", ephemeral: true });
  }

  const target = interaction.options.getMember("العضو");
  const nickname = interaction.options.getString("اللقب") ?? null;

  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });
  if (!target.manageable) return interaction.reply({ content: "❌ لا يمكنني تغيير لقب هذا العضو (رتبته أعلى مني).", ephemeral: true });

  const oldNick = target.nickname ?? target.user.username;
  await target.setNickname(nickname);

  const embed = new EmbedBuilder()
    .setColor(0x9b59b6)
    .setTitle("✏️ تم تغيير اللقب")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "اللقب القديم", value: oldNick, inline: true },
      { name: "اللقب الجديد", value: nickname ?? "*(تمت الإزالة)*", inline: true },
      { name: "بواسطة", value: interaction.user.tag }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
