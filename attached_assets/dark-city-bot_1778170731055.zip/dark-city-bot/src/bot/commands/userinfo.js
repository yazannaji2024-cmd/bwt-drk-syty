import { SlashCommandBuilder, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("معلومات_عضو")
  .setDescription("عرض معلومات عضو")
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المستهدف (اتركه فارغاً لعرض معلوماتك)").setRequired(false)
  );

export async function execute(interaction) {
  const target = interaction.options.getMember("العضو") ?? interaction.member;
  const user = target.user;

  const roles = target.roles.cache
    .filter((r) => r.id !== interaction.guildId)
    .sort((a, b) => b.position - a.position)
    .map((r) => `${r}`)
    .slice(0, 10)
    .join(", ") || "لا يوجد";

  const embed = new EmbedBuilder()
    .setColor(target.displayHexColor === "#000000" ? 0x5865f2 : parseInt(target.displayHexColor.replace("#", ""), 16))
    .setTitle(`👤 معلومات ${user.tag}`)
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: "🆔 ID المستخدم", value: user.id, inline: true },
      { name: "🤖 بوت؟", value: user.bot ? "نعم" : "لا", inline: true },
      { name: "📅 تاريخ الإنشاء", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
      { name: "📥 تاريخ الانضمام", value: target.joinedAt ? `<t:${Math.floor(target.joinedTimestamp / 1000)}:R>` : "غير معروف", inline: true },
      { name: "🎭 أعلى رتبة", value: `${target.roles.highest}`, inline: true },
      { name: "⏰ Timeout حتى", value: target.communicationDisabledUntil ? `<t:${Math.floor(target.communicationDisabledUntilTimestamp / 1000)}:R>` : "لا يوجد", inline: true },
      { name: `🎭 الرتب (${target.roles.cache.size - 1})`, value: roles },
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
