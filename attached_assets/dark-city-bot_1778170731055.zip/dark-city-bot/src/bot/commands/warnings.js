import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";
import { warnings } from "./warn.js";

export const data = new SlashCommandBuilder()
  .setName("الانذارات")
  .setDescription("عرض إنذارات عضو")
  .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المراد عرض إنذاراته").setRequired(true)
  );

export async function execute(interaction) {
  const target = interaction.options.getMember("العضو");

  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });

  const key = `${interaction.guildId}:${target.id}`;
  const userWarnings = warnings.get(key) ?? [];

  if (userWarnings.length === 0) {
    return interaction.reply({ content: `✅ لا توجد إنذارات على **${target.user.tag}**.`, ephemeral: true });
  }

  const embed = new EmbedBuilder()
    .setColor(0xffff00)
    .setTitle(`⚠️ إنذارات ${target.user.tag}`)
    .setDescription(`إجمالي الإنذارات: **${userWarnings.length}**`)
    .addFields(
      userWarnings.slice(-10).map((w, i) => ({
        name: `إنذار #${i + 1}`,
        value: `**السبب:** ${w.reason}\n**بواسطة:** ${w.by}\n**التاريخ:** <t:${Math.floor(w.at.getTime() / 1000)}:R>`,
      }))
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}
