import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

const warnings = new Map();

export const data = new SlashCommandBuilder()
  .setName("انذار")
  .setDescription("إنذار عضو في السيرفر")
  .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المراد إنذاره").setRequired(true)
  )
  .addStringOption((option) =>
    option.setName("السبب").setDescription("سبب الإنذار").setRequired(true)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية إنذار الأعضاء.", ephemeral: true });
  }

  const target = interaction.options.getMember("العضو");
  const reason = interaction.options.getString("السبب", true);

  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });

  const key = `${interaction.guildId}:${target.id}`;
  const userWarnings = warnings.get(key) ?? [];
  userWarnings.push({ reason, by: interaction.user.tag, at: new Date() });
  warnings.set(key, userWarnings);

  try {
    const dmEmbed = new EmbedBuilder()
      .setColor(0xffff00)
      .setAuthor({ name: "تحذير من دارك سيتي" })
      .setTitle("⚠️ تحذير رسمي")
      .addFields(
        { name: "📋 السبب", value: reason },
        { name: "👮 بواسطة", value: interaction.user.tag, inline: true },
        { name: "🔢 عدد تحذيراتك", value: `${userWarnings.length}`, inline: true },
        { name: "📌 ملاحظة", value: "يُرجى الالتزام بقوانين السيرفر." },
      )
      .setTimestamp();
    await target.send({ embeds: [dmEmbed] });
  } catch {
    // DMs disabled
  }

  const embed = new EmbedBuilder()
    .setColor(0xffff00)
    .setTitle("⚠️ تم الإنذار")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "بواسطة", value: `${interaction.user.tag}`, inline: true },
      { name: "عدد الإنذارات", value: `${userWarnings.length}`, inline: true },
      { name: "السبب", value: reason }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

export { warnings };
