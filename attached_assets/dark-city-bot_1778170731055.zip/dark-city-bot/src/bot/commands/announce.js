import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("اعلان")
  .setDescription("إرسال إعلان في قناة محددة")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
  .addStringOption((option) =>
    option.setName("العنوان").setDescription("عنوان الإعلان").setRequired(true)
  )
  .addStringOption((option) =>
    option.setName("الرسالة").setDescription("نص الإعلان").setRequired(true)
  )
  .addChannelOption((option) =>
    option.setName("القناة").setDescription("القناة المراد الإعلان فيها").setRequired(false)
  )
  .addStringOption((option) =>
    option.setName("اللون").setDescription("لون الإعلان (hex مثال: #FF0000)").setRequired(false)
  )
  .addBooleanOption((option) =>
    option.setName("منشن_everyone").setDescription("منشن @everyone مع الإعلان").setRequired(false)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية إرسال الإعلانات.", ephemeral: true });
  }

  const title = interaction.options.getString("العنوان", true);
  const message = interaction.options.getString("الرسالة", true);
  const channel = interaction.options.getChannel("القناة") ?? interaction.channel;
  const colorHex = interaction.options.getString("اللون") ?? "#5865F2";
  const mentionEveryone = interaction.options.getBoolean("منشن_everyone") ?? false;

  let color = 0x5865f2;
  try { color = parseInt(colorHex.replace("#", ""), 16); } catch { }

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(`📢 ${title}`)
    .setDescription(message)
    .addFields({ name: "بواسطة", value: interaction.user.tag })
    .setTimestamp();

  await channel.send({ content: mentionEveryone ? "@everyone" : undefined, embeds: [embed] });
  await interaction.reply({ content: `✅ تم إرسال الإعلان في ${channel}`, ephemeral: true });
}
