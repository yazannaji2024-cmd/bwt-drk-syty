import { SlashCommandBuilder, EmbedBuilder, ChannelType } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("معلومات_سيرفر")
  .setDescription("عرض معلومات السيرفر");

export async function execute(interaction) {
  const guild = interaction.guild;
  if (!guild) return interaction.reply({ content: "❌ لا يمكن تنفيذ هذا الأمر خارج السيرفر.", ephemeral: true });

  await guild.fetch();

  const textChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildText).size;
  const voiceChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildVoice).size;
  const categories = guild.channels.cache.filter((c) => c.type === ChannelType.GuildCategory).size;

  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`📊 معلومات سيرفر ${guild.name}`)
    .setThumbnail(guild.iconURL() ?? null)
    .addFields(
      { name: "🆔 ID السيرفر", value: guild.id, inline: true },
      { name: "👑 المالك", value: `<@${guild.ownerId}>`, inline: true },
      { name: "📅 تاريخ الإنشاء", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
      { name: "👥 عدد الأعضاء", value: `${guild.memberCount}`, inline: true },
      { name: "🚀 مستوى Boost", value: `المستوى ${guild.premiumTier}`, inline: true },
      { name: "💎 عدد Boosts", value: `${guild.premiumSubscriptionCount ?? 0}`, inline: true },
      { name: "💬 قنوات النص", value: `${textChannels}`, inline: true },
      { name: "🔊 قنوات الصوت", value: `${voiceChannels}`, inline: true },
      { name: "📁 الفئات", value: `${categories}`, inline: true },
      { name: "🎭 عدد الرتب", value: `${guild.roles.cache.size}`, inline: true },
      { name: "😀 عدد الإيموجي", value: `${guild.emojis.cache.size}`, inline: true },
      { name: "🌍 المنطقة", value: guild.preferredLocale, inline: true },
    )
    .setImage(guild.bannerURL({ size: 1024 }) ?? null)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
