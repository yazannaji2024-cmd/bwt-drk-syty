import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("رتبة")
  .setDescription("إضافة أو إزالة رتبة من عضو")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
  .addStringOption((option) =>
    option.setName("الإجراء").setDescription("إضافة أو إزالة الرتبة").setRequired(true)
      .addChoices({ name: "إضافة", value: "add" }, { name: "إزالة", value: "remove" })
  )
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المستهدف").setRequired(true)
  )
  .addRoleOption((option) =>
    option.setName("الرتبة").setDescription("الرتبة المراد إضافتها أو إزالتها").setRequired(true)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageRoles)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية إدارة الرتب.", ephemeral: true });
  }

  const action = interaction.options.getString("الإجراء", true);
  const target = interaction.options.getMember("العضو");
  const role = interaction.options.getRole("الرتبة", true);

  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });
  if (role.managed) return interaction.reply({ content: "❌ لا يمكن إدارة هذه الرتبة يدوياً (رتبة مُدارة).", ephemeral: true });

  const botMember = interaction.guild?.members.me;
  if (botMember && role.position >= (botMember.roles.highest.position ?? 0)) {
    return interaction.reply({ content: "❌ الرتبة أعلى من رتبة البوت.", ephemeral: true });
  }

  if (action === "add") await target.roles.add(role.id);
  else await target.roles.remove(role.id);

  const embed = new EmbedBuilder()
    .setColor(action === "add" ? 0x00ff00 : 0xff6600)
    .setTitle(action === "add" ? "✅ تمت إضافة الرتبة" : "❌ تمت إزالة الرتبة")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "الرتبة", value: `${role}`, inline: true },
      { name: "بواسطة", value: interaction.user.tag, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
