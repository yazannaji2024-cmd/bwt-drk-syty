import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("طرد")
  .setDescription("طرد عضو من السيرفر")
  .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المراد طرده").setRequired(true)
  )
  .addStringOption((option) =>
    option.setName("السبب").setDescription("سبب الطرد").setRequired(false)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.KickMembers)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية طرد الأعضاء.", ephemeral: true });
  }

  const target = interaction.options.getMember("العضو");
  const reason = interaction.options.getString("السبب") ?? "لم يُحدد سبب";

  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });
  if (!target.kickable) return interaction.reply({ content: "❌ لا يمكنني طرد هذا العضو (رتبته أعلى مني).", ephemeral: true });

  await target.kick(reason);

  const embed = new EmbedBuilder()
    .setColor(0xff6600)
    .setTitle("👢 تم الطرد")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "بواسطة", value: `${interaction.user.tag}`, inline: true },
      { name: "السبب", value: reason }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
