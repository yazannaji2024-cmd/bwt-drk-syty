import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("رفع_حظر")
  .setDescription("رفع الحظر عن مستخدم")
  .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
  .addStringOption((option) =>
    option.setName("معرف_المستخدم").setDescription("ID المستخدم المراد رفع حظره").setRequired(true)
  )
  .addStringOption((option) =>
    option.setName("السبب").setDescription("سبب رفع الحظر").setRequired(false)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية رفع الحظر.", ephemeral: true });
  }

  const userId = interaction.options.getString("معرف_المستخدم", true);
  const reason = interaction.options.getString("السبب") ?? "لم يُحدد سبب";

  try {
    const ban = await interaction.guild?.bans.fetch(userId);
    if (!ban) return interaction.reply({ content: "❌ هذا المستخدم غير محظور.", ephemeral: true });

    await interaction.guild?.members.unban(userId, reason);

    const embed = new EmbedBuilder()
      .setColor(0x00ff00)
      .setTitle("✅ تم رفع الحظر")
      .addFields(
        { name: "المستخدم", value: `${ban.user.tag}`, inline: true },
        { name: "بواسطة", value: `${interaction.user.tag}`, inline: true },
        { name: "السبب", value: reason }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  } catch {
    await interaction.reply({ content: "❌ لم يتم العثور على هذا المستخدم في قائمة المحظورين.", ephemeral: true });
  }
}
