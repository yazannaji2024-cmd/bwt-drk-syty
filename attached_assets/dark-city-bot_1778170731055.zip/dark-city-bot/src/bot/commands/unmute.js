import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("رفع_كتم")
  .setDescription("رفع الكتم عن عضو")
  .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المراد رفع كتمه").setRequired(true)
  )
  .addStringOption((option) =>
    option.setName("السبب").setDescription("سبب رفع الكتم").setRequired(false)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية رفع الكتم.", ephemeral: true });
  }

  const target = interaction.options.getMember("العضو");
  const reason = interaction.options.getString("السبب") ?? "لم يُحدد سبب";

  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });
  if (!target.isCommunicationDisabled()) return interaction.reply({ content: "❌ هذا العضو غير مكتوم.", ephemeral: true });

  await target.timeout(null, reason);

  const embed = new EmbedBuilder()
    .setColor(0x00ff00)
    .setTitle("🔊 تم رفع الكتم")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "بواسطة", value: `${interaction.user.tag}`, inline: true },
      { name: "السبب", value: reason }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
