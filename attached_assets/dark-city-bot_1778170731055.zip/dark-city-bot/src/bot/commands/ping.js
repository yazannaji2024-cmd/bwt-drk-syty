import { SlashCommandBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("بنج")
  .setDescription("يتحقق من استجابة البوت ويعرض زمن الاستجابة");

export async function execute(interaction) {
  const sent = await interaction.reply({ content: "جاري القياس...", fetchReply: true });
  const latency = sent.createdTimestamp - interaction.createdTimestamp;
  await interaction.editReply(
    `🏓 **بونج!**\n> زمن الاستجابة: **${latency}ms**\n> تأخير API: **${Math.round(interaction.client.ws.ping)}ms**`
  );
}
