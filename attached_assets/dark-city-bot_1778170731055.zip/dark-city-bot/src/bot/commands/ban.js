import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("حظر")
  .setDescription("حظر عضو من السيرفر")
  .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المراد حظره").setRequired(true)
  )
  .addStringOption((option) =>
    option.setName("السبب").setDescription("سبب الحظر").setRequired(false)
  )
  .addIntegerOption((option) =>
    option.setName("حذف_الرسائل").setDescription("حذف رسائل العضو (بالأيام)").setMinValue(0).setMaxValue(7).setRequired(false)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية حظر الأعضاء.", ephemeral: true });
  }

  const target = interaction.options.getMember("العضو");
  const reason = interaction.options.getString("السبب") ?? "لم يُحدد سبب";
  const deleteMessageSeconds = (interaction.options.getInteger("حذف_الرسائل") ?? 0) * 86400;

  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });
  if (!target.bannable) return interaction.reply({ content: "❌ لا يمكنني حظر هذا العضو (رتبته أعلى مني).", ephemeral: true });

  await target.ban({ reason, deleteMessageSeconds });

  const embed = new EmbedBuilder()
    .setColor(0xff0000)
    .setTitle("🔨 تم الحظر")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "بواسطة", value: `${interaction.user.tag}`, inline: true },
      { name: "السبب", value: reason }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
