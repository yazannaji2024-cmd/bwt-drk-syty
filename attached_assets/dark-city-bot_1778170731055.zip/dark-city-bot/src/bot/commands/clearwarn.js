import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";
import { warnings } from "./warn.js";

export const data = new SlashCommandBuilder()
  .setName("مسح_انذارات")
  .setDescription("مسح جميع إنذارات عضو")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addUserOption((option) =>
    option.setName("العضو").setDescription("العضو المراد مسح إنذاراته").setRequired(true)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية مسح الإنذارات.", ephemeral: true });
  }

  const target = interaction.options.getMember("العضو");
  if (!target) return interaction.reply({ content: "❌ لم يتم العثور على العضو.", ephemeral: true });

  const key = `${interaction.guildId}:${target.id}`;
  warnings.delete(key);

  const embed = new EmbedBuilder()
    .setColor(0x00ff00)
    .setTitle("🗑️ تم مسح الإنذارات")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "بواسطة", value: `${interaction.user.tag}`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
