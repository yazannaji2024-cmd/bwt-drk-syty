import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";
import { prisonStore, PRISON_ROLE_ID } from "../data/store.js";

export const data = new SlashCommandBuilder()
  .setName("استرجاع_رتب")
  .setDescription("استرجاع رتب العضو بعد السجن")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
  .addUserOption((o) => o.setName("العضو").setDescription("العضو المراد استرجاع رتبه").setRequired(true))
  .addStringOption((o) => o.setName("السبب").setDescription("سبب الإفراج").setRequired(false));

export async function execute(interaction) {
  const targetUser = interaction.options.getUser("العضو", true);
  const reason = interaction.options.getString("السبب") ?? "لم يُحدد سبب";

  await interaction.deferReply();

  const guild = interaction.guild;
  const target = await guild.members.fetch(targetUser.id).catch(() => null);

  if (!target) return interaction.editReply("❌ لم يتم العثور على العضو.");
  if (!target.manageable) return interaction.editReply("❌ لا يمكنني إدارة هذا العضو.");

  const key = `${guild.id}:${target.id}`;
  const savedRoles = prisonStore.get(key);

  if (!savedRoles || savedRoles.length === 0) return interaction.editReply("❌ لا توجد رتب محفوظة لهذا العضو.");

  const botHighest = guild.members.me?.roles.highest.position ?? 0;
  const restorableRoles = savedRoles.filter((id) => {
    const role = guild.roles.cache.get(id);
    return role && role.position < botHighest;
  });

  await target.roles.set(restorableRoles);
  prisonStore.delete(key);

  const embed = new EmbedBuilder()
    .setColor(0x00ff00)
    .setTitle("🔓 تم الإفراج واسترجاع الرتب")
    .addFields(
      { name: "العضو", value: `${target.user.tag}`, inline: true },
      { name: "بواسطة", value: interaction.user.tag, inline: true },
      { name: "الرتب المستعادة", value: `${restorableRoles.length} رتبة`, inline: true },
      { name: "السبب", value: reason }
    )
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}
