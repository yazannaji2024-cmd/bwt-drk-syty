import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("تباطو")
  .setDescription("تفعيل أو إيقاف وضع التباطؤ في القناة")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
  .addIntegerOption((option) =>
    option.setName("الثواني").setDescription("المدة بالثواني (0 لإلغاء التباطؤ)").setMinValue(0).setMaxValue(21600).setRequired(true)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية إدارة القنوات.", ephemeral: true });
  }

  const seconds = interaction.options.getInteger("الثواني", true);
  const channel = interaction.channel;

  await channel.setRateLimitPerUser(seconds);

  const embed = new EmbedBuilder()
    .setColor(seconds === 0 ? 0x00ff00 : 0xffa500)
    .setTitle(seconds === 0 ? "✅ تم إلغاء التباطؤ" : "🐢 تم تفعيل التباطؤ")
    .setDescription(seconds === 0 ? `تم إلغاء وضع التباطؤ في ${channel}` : `تم تعيين وضع التباطؤ في ${channel} إلى **${seconds} ثانية**`)
    .addFields({ name: "بواسطة", value: interaction.user.tag })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
