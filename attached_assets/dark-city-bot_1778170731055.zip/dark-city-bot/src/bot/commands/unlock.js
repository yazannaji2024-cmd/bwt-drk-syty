import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("فتح")
  .setDescription("فتح قناة مقفلة والسماح للأعضاء بالكتابة")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
  .addStringOption((option) =>
    option.setName("السبب").setDescription("سبب الفتح").setRequired(false)
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
    return interaction.reply({ content: "❌ ليس لديك صلاحية إدارة القنوات.", ephemeral: true });
  }

  const reason = interaction.options.getString("السبب") ?? "لم يُحدد سبب";
  const channel = interaction.channel;
  const everyoneRole = interaction.guild?.roles.everyone;

  if (!everyoneRole) return;

  await channel.permissionOverwrites.edit(everyoneRole, { SendMessages: null });

  const embed = new EmbedBuilder()
    .setColor(0x00ff00)
    .setTitle("🔓 تم فتح القناة")
    .setDescription(`تم فتح ${channel} للكتابة`)
    .addFields(
      { name: "بواسطة", value: interaction.user.tag, inline: true },
      { name: "السبب", value: reason }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
